# yt_pulse_bot/callbacks/__init__.py
# Экспортируем все фабрики для удобства: from callbacks import AdminCallback, MenuCallback, AnalysisCallback
from .admin import AdminCallback
from .menu import MenuCallback
from .analysis import AnalysisCallback