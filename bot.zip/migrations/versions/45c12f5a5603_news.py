"""news

Revision ID: 45c12f5a5603
Revises: e18caf102741
Create Date: 2026-01-15 00:33:27.270404

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '45c12f5a5603'
down_revision: Union[str, Sequence[str], None] = 'e18caf102741'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""

    # 0) Eski admin RBAC jadvallarini xavfsiz olib tashlaymiz.
    # Indexlarni alohida drop qilish shart emas: table drop bo‘lsa indexlar ham ketadi.
    # IF EXISTS + CASCADE => har xil holatlarda ham yiqilmaydi.
    op.execute("DROP TABLE IF EXISTS role_permissions CASCADE")
    op.execute("DROP TABLE IF EXISTS admin_roles CASCADE")
    op.execute("DROP TABLE IF EXISTS admin_password_history CASCADE")
    op.execute("DROP TABLE IF EXISTS admin_audit_logs CASCADE")
    op.execute("DROP TABLE IF EXISTS permissions CASCADE")
    op.execute("DROP TABLE IF EXISTS roles CASCADE")
    op.execute("DROP TABLE IF EXISTS admins CASCADE")

    # 1) Multi-analysis prompts
    op.create_table(
        "multi_analysis_prompts",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("prompt_text", sa.Text(), nullable=False),
        sa.Column("version", sa.String(length=20), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_multi_analysis_prompts_is_active"), "multi_analysis_prompts", ["is_active"], unique=False)

    # 2) Video analysis sets
    op.create_table(
        "video_analysis_sets",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=False),
        sa.Column("video_id", sa.String(length=50), nullable=False),
        sa.Column("db_video_id", sa.Integer(), nullable=True),
        sa.Column("total_analyses", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("best_analysis_id", sa.Integer(), nullable=True),
        sa.Column("last_analysis_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("next_evaluation_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default=sa.text("'collecting'")),
        sa.Column("evaluation_count", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("evaluation_result", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("evaluated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["db_video_id"], ["videos.id"]),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_video_analysis_sets_video_id"), "video_analysis_sets", ["video_id"], unique=False)

    # 3) ai_responses columns + FK
    op.add_column("ai_responses", sa.Column("pdf_file_path", sa.String(length=500), nullable=True))
    op.add_column("ai_responses", sa.Column("analysis_set_id", sa.Integer(), nullable=True))
    op.add_column(
        "ai_responses",
        sa.Column("is_for_strategic_hub", sa.Boolean(), nullable=False, server_default=sa.text("false")),
    )
    op.create_foreign_key(
        "fk_ai_responses_analysis_set_id",
        "ai_responses",
        "video_analysis_sets",
        ["analysis_set_id"],
        ["id"],
        ondelete="SET NULL",
    )

    # 4) Quality markers
    op.create_table(
        "analysis_quality_markers",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("analysis_set_id", sa.Integer(), nullable=False),
        sa.Column("analysis_id", sa.Integer(), nullable=False),
        sa.Column("quality_rank", sa.Integer(), nullable=True),
        sa.Column("is_best", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("total_score", sa.Float(), nullable=True),
        sa.Column("scores", sa.JSON(), nullable=True),
        sa.Column("strengths", sa.JSON(), nullable=True),
        sa.Column("weaknesses", sa.JSON(), nullable=True),
        sa.Column("improvement_suggestions", sa.JSON(), nullable=True),
        sa.Column("pdf_deleted", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("pdf_deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("evaluation_metadata", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.ForeignKeyConstraint(["analysis_id"], ["ai_responses.id"]),
        sa.ForeignKeyConstraint(["analysis_set_id"], ["video_analysis_sets.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_analysis_quality_markers_analysis_id"), "analysis_quality_markers", ["analysis_id"], unique=False)
    op.create_index(op.f("ix_analysis_quality_markers_analysis_set_id"), "analysis_quality_markers", ["analysis_set_id"], unique=False)
    op.create_index(op.f("ix_analysis_quality_markers_is_best"), "analysis_quality_markers", ["is_best"], unique=False)
    op.create_index(op.f("ix_analysis_quality_markers_quality_rank"), "analysis_quality_markers", ["quality_rank"], unique=False)



def downgrade() -> None:
    """Downgrade schema."""
    # ### commands auto generated by Alembic - please adjust! ###
    op.drop_constraint(None, 'ai_responses', type_='foreignkey')
    op.drop_column('ai_responses', 'is_for_strategic_hub')
    op.drop_column('ai_responses', 'analysis_set_id')
    op.drop_column('ai_responses', 'pdf_file_path')
    op.create_table('role_permissions',
    sa.Column('role_id', sa.INTEGER(), autoincrement=False, nullable=False),
    sa.Column('permission_id', sa.INTEGER(), autoincrement=False, nullable=False),
    sa.ForeignKeyConstraint(['permission_id'], ['permissions.id'], name=op.f('role_permissions_permission_id_fkey'), ondelete='CASCADE'),
    sa.ForeignKeyConstraint(['role_id'], ['roles.id'], name=op.f('role_permissions_role_id_fkey'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('role_id', 'permission_id', name=op.f('uq_role_permission'))
    )
    op.create_table('admin_audit_logs',
    sa.Column('id', sa.INTEGER(), autoincrement=True, nullable=False),
    sa.Column('admin_id', sa.INTEGER(), autoincrement=False, nullable=True),
    sa.Column('action', sa.VARCHAR(length=100), autoincrement=False, nullable=False),
    sa.Column('resource_type', sa.VARCHAR(length=100), autoincrement=False, nullable=True),
    sa.Column('resource_id', sa.VARCHAR(length=100), autoincrement=False, nullable=True),
    sa.Column('old_values', postgresql.JSON(astext_type=sa.Text()), autoincrement=False, nullable=True),
    sa.Column('new_values', postgresql.JSON(astext_type=sa.Text()), autoincrement=False, nullable=True),
    sa.Column('ip_address', sa.VARCHAR(length=45), autoincrement=False, nullable=True),
    sa.Column('user_agent', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
    sa.Column('created_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.ForeignKeyConstraint(['admin_id'], ['admins.id'], name=op.f('admin_audit_logs_admin_id_fkey'), ondelete='SET NULL'),
    sa.PrimaryKeyConstraint('id', name=op.f('admin_audit_logs_pkey'))
    )
    op.create_table('admin_roles',
    sa.Column('admin_id', sa.INTEGER(), autoincrement=False, nullable=False),
    sa.Column('role_id', sa.INTEGER(), autoincrement=False, nullable=False),
    sa.ForeignKeyConstraint(['admin_id'], ['admins.id'], name=op.f('admin_roles_admin_id_fkey'), ondelete='CASCADE'),
    sa.ForeignKeyConstraint(['role_id'], ['roles.id'], name=op.f('admin_roles_role_id_fkey'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('admin_id', 'role_id', name=op.f('admin_roles_pkey'))
    )
    op.create_table('roles',
    sa.Column('id', sa.INTEGER(), autoincrement=True, nullable=False),
    sa.Column('name', sa.VARCHAR(length=100), autoincrement=False, nullable=False),
    sa.Column('description', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
    sa.Column('is_system', sa.BOOLEAN(), autoincrement=False, nullable=False),
    sa.Column('created_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.Column('updated_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('roles_pkey'))
    )
    op.create_index(op.f('ix_roles_name'), 'roles', ['name'], unique=True)
    op.create_table('permissions',
    sa.Column('id', sa.INTEGER(), autoincrement=True, nullable=False),
    sa.Column('code', sa.VARCHAR(length=100), autoincrement=False, nullable=False),
    sa.Column('name', sa.VARCHAR(length=255), autoincrement=False, nullable=False),
    sa.Column('description', sa.VARCHAR(length=500), autoincrement=False, nullable=True),
    sa.Column('category', sa.VARCHAR(length=100), autoincrement=False, nullable=True),
    sa.Column('module', sa.VARCHAR(length=100), autoincrement=False, nullable=True),
    sa.Column('created_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('permissions_pkey'))
    )
    op.create_index(op.f('ix_permissions_code'), 'permissions', ['code'], unique=True)
    op.create_table('admin_password_history',
    sa.Column('id', sa.INTEGER(), autoincrement=True, nullable=False),
    sa.Column('admin_id', sa.INTEGER(), autoincrement=False, nullable=False),
    sa.Column('password_hash', sa.VARCHAR(length=255), autoincrement=False, nullable=False),
    sa.Column('created_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.ForeignKeyConstraint(['admin_id'], ['admins.id'], name=op.f('admin_password_history_admin_id_fkey'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('admin_password_history_pkey'))
    )
    op.create_table('admins',
    sa.Column('id', sa.INTEGER(), autoincrement=True, nullable=False),
    sa.Column('username', sa.VARCHAR(length=50), autoincrement=False, nullable=False),
    sa.Column('email', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
    sa.Column('full_name', sa.VARCHAR(length=255), autoincrement=False, nullable=True),
    sa.Column('password_hash', sa.VARCHAR(length=255), autoincrement=False, nullable=False),
    sa.Column('is_active', sa.BOOLEAN(), autoincrement=False, nullable=False),
    sa.Column('is_superuser', sa.BOOLEAN(), autoincrement=False, nullable=False),
    sa.Column('created_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.Column('updated_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.Column('last_login_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=True),
    sa.Column('last_login_ip', sa.VARCHAR(length=45), autoincrement=False, nullable=True),
    sa.PrimaryKeyConstraint('id', name=op.f('admins_pkey'))
    )
    op.create_index(op.f('ix_admins_username'), 'admins', ['username'], unique=True)
    op.create_index(op.f('ix_admins_id'), 'admins', ['id'], unique=False)
    op.create_index(op.f('ix_admins_email'), 'admins', ['email'], unique=True)
    op.drop_index(op.f('ix_analysis_quality_markers_quality_rank'), table_name='analysis_quality_markers')
    op.drop_index(op.f('ix_analysis_quality_markers_is_best'), table_name='analysis_quality_markers')
    op.drop_index(op.f('ix_analysis_quality_markers_analysis_set_id'), table_name='analysis_quality_markers')
    op.drop_index(op.f('ix_analysis_quality_markers_analysis_id'), table_name='analysis_quality_markers')
    op.drop_table('analysis_quality_markers')
    op.drop_index(op.f('ix_video_analysis_sets_video_id'), table_name='video_analysis_sets')
    op.drop_table('video_analysis_sets')
    op.drop_index(op.f('ix_multi_analysis_prompts_is_active'), table_name='multi_analysis_prompts')
    op.drop_table('multi_analysis_prompts')
    # ### end Alembic commands ###
