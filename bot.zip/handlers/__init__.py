from .start import router as start_router
from .menu import router as menu_router
from .analysis import router as analysis_router
from .cabinet import router as cabinet_router
from .admin import router as admin_router
from .verification_handler import router  as verification_router
from .evolution import router as evolution_router
from .shorts_handler import router as shorts_router