// src/components/PromptModal.jsx
import { useState } from 'react';
import { X, Upload } from 'lucide-react';
import AdminAPI from '../api/api';

const PromptModal = ({ prompt, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: prompt?.name || '',
    category: prompt?.category || 'my',
    analysis_type: prompt?.analysis_type || 'simple',
    module_id: prompt?.module_id || '',
    prompt_text: prompt?.prompt_text || '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const categories = [
    { value: 'my', label: 'Моё видео' },
    { value: 'competitor', label: 'Конкурент' },
    { value: 'shorts', label: 'Shorts' },
    { value: 'evolution', label: 'Эволюция' },
  ];

  const analysisTypes = [
    { value: 'simple', label: 'Simple' },
    { value: 'advanced', label: 'Advanced' },
    { value: 'synthesis', label: 'Synthesis' },
    { value: 'evolution_step1', label: 'Evolution Step 1' },
    { value: 'evolution_step2', label: 'Evolution Step 2' },
  ];

  const handleSubmit = async () => {
    if (!formData.name || !formData.prompt_text) {
      setError('Заполните обязательные поля');
      return;
    }

    setLoading(true);
    setError('');

    try {
      if (prompt) {
        await AdminAPI.updatePrompt(prompt.id, formData);
      } else {
        await AdminAPI.createPrompt(formData);
      }
      onSave();
      onClose();
    } catch (err) {
      setError('Ошибка сохранения');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'text/plain') {
      setError('Только .txt файлы');
      return;
    }

    try {
      const text = await file.text();
      setFormData({ ...formData, prompt_text: text });
      setError('');
    } catch (err) {
      setError('Ошибка чтения файла');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <h3 className="text-xl font-bold text-gray-800">
            {prompt ? '✏️ Редактировать промпт' : '➕ Новый промпт'}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Error */}
        {error && (
          <div className="mx-6 mt-4 p-3 bg-red-100 border border-red-300 rounded-xl text-red-700 text-sm">
            {error}
          </div>
        )}

        {/* Form */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Название <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
                placeholder="Название промпта"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Категория
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
              >
                {categories.map((cat) => (
                  <option key={cat.value} value={cat.value}>
                    {cat.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Analysis Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Тип анализа
              </label>
              <select
                value={formData.analysis_type}
                onChange={(e) => setFormData({ ...formData, analysis_type: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
              >
                {analysisTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Module ID (only for advanced) */}
            {formData.analysis_type === 'advanced' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Модуль ID
                </label>
                <input
                  type="text"
                  value={formData.module_id}
                  onChange={(e) => setFormData({ ...formData, module_id: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
                  placeholder="501, 502, etc."
                />
              </div>
            )}
          </div>

          {/* Prompt Text */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Текст промпта <span className="text-red-500">*</span>
              </label>
              <label className="flex items-center gap-2 px-3 py-1 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 cursor-pointer text-sm">
                <Upload className="w-4 h-4" />
                Загрузить .txt
                <input
                  type="file"
                  accept=".txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
            <textarea
              value={formData.prompt_text}
              onChange={(e) => setFormData({ ...formData, prompt_text: e.target.value })}
              rows={12}
              className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
              placeholder="Введите текст промпта или загрузите .txt файл"
            />
            <div className="mt-2 text-xs text-gray-500">
              Символов: {formData.prompt_text.length}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 flex gap-3 justify-end sticky bottom-0 bg-white">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 rounded-xl hover:bg-gray-50 transition"
          >
            Отмена
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="px-6 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-xl hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Сохранение...
              </div>
            ) : (
              '💾 Сохранить'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PromptModal;