export const CATEGORIES = [
  { value: "my", label: "Мой канал" },
  { value: "competitor", label: "Канал конкурента" },
];

export const LEVELS = [
  { value: "simple", label: "Простой анализ" },
  { value: "advanced", label: "Углубленный анализ" },
];

export const MODULES = [
  { value: "10-1", label: "10-1 • Контент" },
  { value: "10-2", label: "10-2 • Аудитория" },
  { value: "10-3", label: "10-3 • Вовлеченность" },
  { value: "10-4", label: "10-4 • Стратегия роста" },
];
