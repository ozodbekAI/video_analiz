// src/pages/PromptsPage.jsx
import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Search, Filter } from 'lucide-react';
import AdminAPI from '../api/api';
import PromptModal from '../components/PromptModal';

const PromptsPage = () => {
  const [prompts, setPrompts] = useState([]);
  const [category, setCategory] = useState('my');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingPrompt, setEditingPrompt] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPrompts();
  }, [category]);

  const loadPrompts = async () => {
    setLoading(true);
    try {
      const data = await AdminAPI.getPrompts(category);
      setPrompts(data);
    } catch (error) {
      console.error('Failed to load prompts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Удалить промпт?')) return;
    
    try {
      await AdminAPI.deletePrompt(id);
      loadPrompts();
    } catch (error) {
      alert('Ошибка удаления');
    }
  };

  const filteredPrompts = prompts.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const categories = [
    { value: 'my', label: '📹 Моё видео' },
    { value: 'competitor', label: '🎯 Конкурент' },
    { value: 'shorts', label: '⚡ Shorts' },
    { value: 'evolution', label: '📊 Эволюция' },
  ];

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Промпты</h1>
          <p className="text-gray-500 mt-1">Управление AI промптами</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-6 py-3 rounded-xl flex items-center gap-2 hover:shadow-lg transform hover:-translate-y-0.5 transition"
        >
          <Plus className="w-5 h-5" />
          Добавить промпт
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Поиск промптов..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 flex-wrap">
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setCategory(cat.value)}
                className={`px-4 py-2 rounded-xl font-medium transition ${
                  category === cat.value
                    ? 'bg-indigo-500 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-4 pt-4 border-t border-gray-200 flex gap-4 text-sm text-gray-600">
          <div>
            Всего: <span className="font-semibold text-gray-800">{prompts.length}</span>
          </div>
          <div>
            Найдено: <span className="font-semibold text-gray-800">{filteredPrompts.length}</span>
          </div>
        </div>
      </div>

      {/* Prompts List */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filteredPrompts.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
          <div className="text-6xl mb-4">📝</div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            Промпты не найдены
          </h3>
          <p className="text-gray-500">
            {searchTerm
              ? 'Попробуйте изменить поисковый запрос'
              : 'Добавьте первый промпт для этой категории'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPrompts.map((prompt) => (
            <div
              key={prompt.id}
              className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">
                    {prompt.name}
                  </h3>
                  
                  <div className="flex gap-2 flex-wrap">
                    <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-lg text-sm font-medium">
                      {prompt.analysis_type}
                    </span>
                    {prompt.module_id && (
                      <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-lg text-sm font-medium">
                        Module: {prompt.module_id}
                      </span>
                    )}
                    <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-lg text-sm">
                      {prompt.prompt_text?.length || 0} символов
                    </span>
                  </div>

                  {/* Preview */}
                  <div className="mt-3 p-3 bg-gray-50 rounded-xl text-sm text-gray-600 font-mono line-clamp-2">
                    {prompt.prompt_text?.substring(0, 150)}...
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => setEditingPrompt(prompt)}
                    className="p-2 bg-blue-100 text-blue-600 rounded-xl hover:bg-blue-200 transition"
                    title="Редактировать"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(prompt.id)}
                    className="p-2 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition"
                    title="Удалить"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      {showAddModal && (
        <PromptModal
          onClose={() => setShowAddModal(false)}
          onSave={loadPrompts}
        />
      )}

      {editingPrompt && (
        <PromptModal
          prompt={editingPrompt}
          onClose={() => setEditingPrompt(null)}
          onSave={loadPrompts}
        />
      )}
    </div>
  );
};

export default PromptsPage;