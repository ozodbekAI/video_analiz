import { useState } from "react";
import { api } from "../api/api";
import PromptForm from "../components/PromptForm";

export default function AddPrompt() {
  const [data, setData] = useState({
    name: "",
    category: "my",
    level: "simple",
    module: "",
    text: "",
  });

  function update(field, value) {
    setData({ ...data, [field]: value });
  }

  async function save() {
    await api.post("/admin/prompts/", {
      name: data.name,
      category: data.category,
      analysis_type: data.level,
      module_id: data.level === "advanced" ? data.module : null,
      prompt_text: data.text,
    });

    alert("Промпт добавлен");
    setData({ ...data, name: "", text: "" });
  }

  return (
    <div className="p-8 max-w-4xl">
      <h2 className="text-2xl font-bold mb-6">➕ Новый промпт</h2>
      <PromptForm data={data} onChange={update} />
      <button onClick={save} className="btn-primary mt-6">
        💾 Сохранить
      </button>
    </div>
  );
}
