from fastapi import APIRouter, Depends, Body
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import List, Optional

from database.engine import async_session
from database.models import Prompt
from database.crud import (
    get_prompts,
    create_prompt,
    update_prompt,
    delete_prompt,
)
from database.crud import get_advanced_with_synthesis
from admin_panel.backend.core.auth import admin_auth

router = APIRouter(prefix="/admin/prompts", tags=["Admin Prompts"])


# ====== SCHEMAS ======
class PromptCreate(BaseModel):
    name: str
    prompt_text: str
    category: str
    analysis_type: str


class PromptReorderItem(BaseModel):
    id: int
    order: int


class PromptReorder(BaseModel):
    orders: List[PromptReorderItem]


# ====== ENDPOINTS ======
@router.get("/")
async def list_prompts(
    category: str | None = None,
    db: AsyncSession = Depends(async_session),
    _: str = Depends(admin_auth),
):
    if category:
        return await get_advanced_with_synthesis(category, db)

    return await get_prompts()

@router.post("/")
async def add_prompt(
    data: PromptCreate,
    _: str = Depends(admin_auth),
):
    await create_prompt(
        name=data.name,
        prompt_text=data.prompt_text,
        analysis_type=data.analysis_type,
        category=data.category,
    )
    return {"status": "ok"}


@router.put("/{prompt_id}")
async def edit_prompt(
    prompt_id: int,
    prompt_text: str = Body(...),
    _: str = Depends(admin_auth),
):
    await update_prompt(prompt_id, prompt_text)
    return {"status": "updated"}


@router.delete("/{prompt_id}")
async def remove_prompt(
    prompt_id: int,
    _: str = Depends(admin_auth),
):
    await delete_prompt(prompt_id)
    return {"status": "deleted"}


@router.post("/reorder")
async def reorder_prompts(
    data: PromptReorder,
    db: AsyncSession = Depends(async_session),
    _: str = Depends(admin_auth),
):
    for item in data.orders:
        await db.execute(
            Prompt.__table__
            .update()
            .where(Prompt.id == item.id)
            .values(order=item.order)
        )
    await db.commit()
    return {"status": "reordered"}
