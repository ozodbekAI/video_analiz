import { useEffect, useState } from "react";
import { api } from "../api/api";
import PromptForm from "../components/PromptForm";
import { useParams, useNavigate } from "react-router-dom";

export default function EditPrompt() {
  const { id } = useParams();
  const nav = useNavigate();
  const [data, setData] = useState(null);

  useEffect(() => {
    api.get(`/admin/prompts/${id}`).then(r => {
      setData({
        name: r.data.name,
        category: r.data.category,
        level: r.data.analysis_type,
        module: r.data.module_id || "",
        text: r.data.prompt_text,
      });
    });
  }, [id]);

  function update(field, value) {
    setData({ ...data, [field]: value });
  }

  async function save() {
    await api.put(`/admin/prompts/${id}`, {
      name: data.name,
      category: data.category,
      analysis_type: data.level,
      module_id: data.level === "advanced" ? data.module : null,
      prompt_text: data.text,
    });

    alert("Промпт обновлён");
    nav("/prompts");
  }

  if (!data) return null;

  return (
    <div className="p-8 max-w-4xl">
      <h2 className="text-2xl font-bold mb-6">✏️ Редактирование</h2>
      <PromptForm data={data} onChange={update} />
      <button onClick={save} className="btn-primary mt-6">
        💾 Обновить
      </button>
    </div>
  );
}
