// src/pages/Dashboard.jsx
import { useState, useEffect } from 'react';
import { Users, FileText, BarChart3, Brain, TrendingUp, Calendar } from 'lucide-react';
import AdminAPI from '../api/api';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await AdminAPI.getStats();
      setStats(data);
    } catch (err) {
      setError('Ошибка загрузки статистики');
      console.error('Failed to load stats:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-2xl p-6 text-center">
        <p className="text-red-600">{error}</p>
        <button
          onClick={loadStats}
          className="mt-4 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700"
        >
          Повторить
        </button>
      </div>
    );
  }

  const cards = [
    {
      title: 'Total Users',
      value: stats?.total_users || 0,
      icon: Users,
      color: 'from-blue-500 to-cyan-500',
      today: stats?.users_today || 0,
    },
    {
      title: 'Total Videos',
      value: stats?.total_videos || 0,
      icon: FileText,
      color: 'from-purple-500 to-pink-500',
      today: stats?.videos_today || 0,
    },
    {
      title: 'AI Requests',
      value: stats?.total_ai_requests || 0,
      icon: BarChart3,
      color: 'from-orange-500 to-red-500',
      today: stats?.ai_requests_today || 0,
    },
    {
      title: 'Prompts',
      value: stats?.prompts_count || 0,
      icon: Brain,
      color: 'from-green-500 to-teal-500',
      today: null,
    },
  ];

  return (
    <div>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Дашборд</h1>
        <p className="text-gray-500">Обзор статистики системы</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {cards.map((card, idx) => (
          <div
            key={idx}
            className={`bg-gradient-to-br ${card.color} rounded-2xl p-6 text-white shadow-lg transform hover:scale-105 transition cursor-pointer`}
          >
            <div className="flex items-center justify-between mb-4">
              <card.icon className="w-8 h-8 opacity-80" />
              <div className="text-3xl font-bold">{card.value}</div>
            </div>
            <div className="text-sm opacity-90 mb-2">{card.title}</div>
            {card.today !== null && (
              <div className="flex items-center gap-2 text-xs opacity-75">
                <TrendingUp className="w-4 h-4" />
                <span>Сегодня: {card.today}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Analysis Types */}
      {stats?.analysis_type_stats && (
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Типы анализов</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(stats.analysis_type_stats).map(([type, count]) => (
              <div
                key={type}
                className="bg-gray-50 rounded-xl p-4 border border-gray-200"
              >
                <div className="text-2xl font-bold text-gray-800 mb-1">{count}</div>
                <div className="text-sm text-gray-600 capitalize">{type}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Быстрые действия</h3>
          <div className="space-y-3">
            <button className="w-full px-4 py-3 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-100 transition text-left">
              ➕ Добавить промпт
            </button>
            <button className="w-full px-4 py-3 bg-purple-50 text-purple-600 rounded-xl hover:bg-purple-100 transition text-left">
              📊 Экспорт статистики
            </button>
            <button className="w-full px-4 py-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition text-left">
              👥 Управление пользователями
            </button>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Системная информация</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">Версия:</span>
              <span className="font-semibold">v2.0.0</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">Последнее обновление:</span>
              <span className="font-semibold">
                {new Date().toLocaleDateString('ru-RU')}
              </span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-600">Статус:</span>
              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-lg text-sm">
                ✓ Активен
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;