// src/App.jsx
import { useState, useEffect } from 'react';
import AdminAPI from './api/api';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import PromptsPage from './pages/PromptsPage';
import UsersPage from './pages/UsersPage';
import SamplesPage from './pages/SamplesPage';
import Sidebar from './components/Sidebar';

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    // Check if user is already authenticated
    const token = localStorage.getItem('admin_token');
    if (token) {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    AdminAPI.clearToken();
    setIsAuthenticated(false);
    setActiveTab('dashboard');
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'prompts' && <PromptsPage />}
        {activeTab === 'users' && <UsersPage />}
        {activeTab === 'samples' && <SamplesPage />}
      </div>
    </div>
  );
};

export default App;