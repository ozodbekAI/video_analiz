import { CATEGORIES, LEVELS, MODULES } from "../constants/promptOptions";

export default function PromptForm({ data, onChange }) {
  return (
    <div className="space-y-4">
      <input className="input" placeholder="Название" value={data.name} onChange={e => onChange("name", e.target.value)} />

      <select className="input" value={data.category} onChange={e => onChange("category", e.target.value)}>
        {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
      </select>

      <select className="input" value={data.level} onChange={e => onChange("level", e.target.value)}>
        {LEVELS.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
      </select>

      {data.level === "advanced" && (
        <select className="input" value={data.module} onChange={e => onChange("module", e.target.value)}>
          <option value="">Выберите модуль</option>
          {MODULES.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
        </select>
      )}

      <textarea rows={12} className="input" placeholder="Текст промпта" value={data.text} onChange={e => onChange("text", e.target.value)} />
    </div>
  );
}
