// src/api/api.js
const API_BASE = 'http://localhost:8000';

class AdminAPI {
  static token = localStorage.getItem('admin_token') || '';

  static setToken(token) {
    this.token = token;
    localStorage.setItem('admin_token', token);
  }

  static clearToken() {
    this.token = '';
    localStorage.removeItem('admin_token');
  }

  static async request(endpoint, options = {}) {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': this.token ? `Bearer ${this.token}` : '',
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
  }

  // ==================== AUTH ====================
  static async login(username, password) {
    const data = await this.request(`/admin/login?username=${username}&password=${password}`, {
      method: 'POST',
    });
    this.setToken(data.token);
    return data;
  }

  // ==================== PROMPTS ====================
  static async getPrompts(category = null) {
    const url = category ? `/admin/prompts/?category=${category}` : '/admin/prompts/';
    return this.request(url);
  }

  static async getPromptById(id) {
    return this.request(`/admin/prompts/${id}`);
  }

  static async createPrompt(data) {
    return this.request('/admin/prompts/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  static async updatePrompt(id, data) {
    return this.request(`/admin/prompts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  static async deletePrompt(id) {
    return this.request(`/admin/prompts/${id}`, {
      method: 'DELETE',
    });
  }

  static async reorderPrompts(orders) {
    return this.request('/admin/prompts/reorder', {
      method: 'POST',
      body: JSON.stringify({ orders }),
    });
  }

  // ==================== STATS ====================
  static async getStats() {
    return this.request('/admin/stats');
  }

  static async getTopUsers(limit = 10) {
    return this.request(`/admin/stats/top-users?limit=${limit}`);
  }

  static async getRecentVideos(limit = 10) {
    return this.request(`/admin/stats/recent-videos?limit=${limit}`);
  }

  // ==================== USERS ====================
  static async getUsers(search = '', page = 1, limit = 20) {
    const params = new URLSearchParams({ search, page, limit });
    return this.request(`/admin/users?${params}`);
  }

  static async getUserById(userId) {
    return this.request(`/admin/users/${userId}`);
  }

  static async updateUserLimit(userId, limit) {
    return this.request(`/admin/users/${userId}/limit`, {
      method: 'PUT',
      body: JSON.stringify({ limit }),
    });
  }

  static async resetUserUsage(userId) {
    return this.request(`/admin/users/${userId}/reset`, {
      method: 'POST',
    });
  }

  static async updateUserTariff(userId, tariff) {
    return this.request(`/admin/users/${userId}/tariff`, {
      method: 'PUT',
      body: JSON.stringify({ tariff }),
    });
  }

  // ==================== SAMPLE REPORTS ====================
  static async getSampleReports(videoType = null) {
    const url = videoType 
      ? `/admin/samples?video_type=${videoType}` 
      : '/admin/samples';
    return this.request(url);
  }

  static async getSampleReportById(id) {
    return this.request(`/admin/samples/${id}`);
  }

  static async createSampleReport(data) {
    return this.request('/admin/samples', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  static async toggleSampleReport(id) {
    return this.request(`/admin/samples/${id}/toggle`, {
      method: 'POST',
    });
  }

  static async deleteSampleReport(id) {
    return this.request(`/admin/samples/${id}`, {
      method: 'DELETE',
    });
  }

  // ==================== FILE UPLOAD ====================
  static async uploadFile(file, type = 'prompt') {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);

    const response = await fetch(`${API_BASE}/admin/upload`, {
      method: 'POST',
      headers: {
        'Authorization': this.token ? `Bearer ${this.token}` : '',
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Upload failed: ${response.status}`);
    }

    return response.json();
  }
}

export default AdminAPI;