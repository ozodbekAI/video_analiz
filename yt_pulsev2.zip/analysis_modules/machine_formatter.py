import json
from datetime import datetime
from typing import Dict, List, Any

class MachineReadableFormatter:
    def __init__(self):
        self.version = "1.0"
    
    def create_machine_report(self, 
                            video_meta: Dict,
                            modules_data: Dict[str, str],
                            calculated_indices: Dict,
                            human_insights: List[Dict],
                            validation_report: Dict) -> str:
        """
        Создает полный машиночитаемый отчет со ВСЕМИ данными
        """
        
        # Извлекаем сущности из всех модулей
        entities = self._extract_all_entities(modules_data)
        
        machine_report = {
            "metadata": {
                "format_version": self.version,
                "report_type": "video_analysis",
                "video_id": video_meta.get("video_id"),
                "video_url": video_meta.get("video_url"),
                "video_title": video_meta.get("video_title"),
                "upload_date": video_meta.get("upload_date"),
                "analysis_date": datetime.now().strftime("%Y-%m-%d"),
                "analysis_timestamp": datetime.now().isoformat(),
                "comment_count": video_meta.get("comment_count"),
                "user_id": video_meta.get("user_id")
            },
            
            "strategic_indices": {
                "content_health_index": calculated_indices.get("content_health_index"),
                "audience_evolution_vector": calculated_indices.get("audience_evolution_vector"),
                "overall_priority": calculated_indices.get("overall_priority"),
                "quality_score": calculated_indices.get("quality_score"),
                "calculation_timestamp": datetime.now().isoformat()
            },
            
            "entities": entities,
            
            "cross_module_insights": human_insights,
            
            "raw_modules_data": {
                "module_10_1": modules_data.get("10-1", ""),
                "module_10_2": modules_data.get("10-2", ""),
                "module_10_3": modules_data.get("10-3", ""),
                "module_10_4": modules_data.get("10-4", "")
            },
            
            "validation": {
                "quality_index": validation_report.get("quality_index"),
                "present_modules": validation_report.get("present_modules", []),
                "missing_modules": validation_report.get("missing_modules", []),
                "warnings": validation_report.get("quality_warnings", [])
            },
            
            "aggregation_metadata": {
                "is_aggregation_ready": True,
                "required_fields_present": self._check_required_fields(entities, calculated_indices),
                "data_completeness_score": self._calculate_completeness_score(entities, human_insights),
                "next_aggregation_step": "channel_trend_analysis"
            }
        }
        
        return json.dumps(machine_report, ensure_ascii=False, indent=2)
    
    def _extract_all_entities(self, modules_data: Dict[str, str]) -> Dict[str, List]:
        """Извлекает все сущности из всех модулей"""
        return {
            "themes": self._extract_themes(modules_data.get("10-1", "")),
            "emotions": self._extract_emotions(modules_data.get("10-2", "")),
            "personas": self._extract_personas(modules_data.get("10-3", "")),
            "risks": self._extract_risks(modules_data.get("10-4", "")),
            "opportunities": self._extract_opportunities(modules_data.get("10-4", "")),
            "connections": self._extract_cross_module_connections(modules_data)
        }
    
    def _extract_themes(self, module_10_1_content: str) -> List[Dict]:
        """Извлекает темы из модуля 10-1"""
        themes = []
        
        # Парсим таблицу тем
        lines = module_10_1_content.split('\n')
        in_table = False
        
        for line in lines:
            if "СВОДНАЯ ТАБЛИЦА ДЛЯ СИНТЕЗА" in line:
                in_table = True
                continue
            if in_table and line.strip().startswith('|') and 'ThemeID' in line:
                continue  # Пропускаем заголовок таблицы
            if in_table and line.strip().startswith('|') and '---' not in line:
                parts = [part.strip() for part in line.split('|') if part.strip()]
                if len(parts) >= 8:
                    themes.append({
                        "theme_id": parts[0],
                        "name": parts[1],
                        "category": parts[2],
                        "mentions": int(parts[3]) if parts[3].isdigit() else 0,
                        "norm_mentions": float(parts[4]) if self._is_float(parts[4]) else 0.0,
                        "topic_score": int(parts[5]) if parts[5].isdigit() else 0,
                        "priority": parts[6],
                        "evolution_stage": parts[7],
                        "module_source": "10-1"
                    })
        
        return themes
    
    def _extract_emotions(self, module_10_2_content: str) -> List[Dict]:
        """Извлекает эмоции из модуля 10-2"""
        emotions = []
        
        lines = module_10_2_content.split('\n')
        in_table = False
        
        for line in lines:
            if "СВОДНАЯ ТАБЛИЦА ДЛЯ СИНТЕЗА" in line:
                in_table = True
                continue
            if in_table and line.strip().startswith('|') and 'EmotionID' in line:
                continue
            if in_table and line.strip().startswith('|') and '---' not in line:
                parts = [part.strip() for part in line.split('|') if part.strip()]
                if len(parts) >= 9:
                    emotions.append({
                        "emotion_id": parts[0],
                        "trigger": parts[1],
                        "dominant_emotion": parts[2],
                        "mentions": int(parts[3]) if parts[3].isdigit() else 0,
                        "norm_mentions": float(parts[4]) if self._is_float(parts[4]) else 0.0,
                        "emotional_charge": float(parts[5]) if self._is_float(parts[5]) else 0.0,
                        "intensity": float(parts[6]) if self._is_float(parts[6]) else 0.0,
                        "priority": parts[7],
                        "trend": parts[8],
                        "module_source": "10-2"
                    })
        
        return emotions
    
    def _extract_personas(self, module_10_3_content: str) -> List[Dict]:
        """Извлекает персоны из модуля 10-3"""
        personas = []
        
        lines = module_10_3_content.split('\n')
        in_table = False
        
        for line in lines:
            if "СВОДНАЯ ТАБЛИЦА ДЛЯ СИНТЕЗА" in line:
                in_table = True
                continue
            if in_table and line.strip().startswith('|') and 'PersonaID' in line:
                continue
            if in_table and line.strip().startswith('|') and '---' not in line:
                parts = [part.strip() for part in line.split('|') if part.strip()]
                if len(parts) >= 9:
                    personas.append({
                        "persona_id": parts[0],
                        "name": parts[1],
                        "type": parts[2],
                        "segment_size": int(parts[3]) if parts[3].isdigit() else 0,
                        "norm_size": int(parts[4]) if parts[4].isdigit() else 0,
                        "influence_index": float(parts[5]) if self._is_float(parts[5]) else 0.0,
                        "engagement": float(parts[6]) if self._is_float(parts[6]) else 0.0,
                        "priority": parts[7],
                        "development_stage": parts[8],
                        "module_source": "10-3"
                    })
        
        return personas
    
    def _extract_risks(self, module_10_4_content: str) -> List[Dict]:
        """Извлекает риски из модуля 10-4"""
        risks = []
        
        lines = module_10_4_content.split('\n')
        in_table = False
        
        for line in lines:
            if "СВОДНАЯ ТАБЛИЦА ПРИОРИТЕТОВ" in line:
                in_table = True
                continue
            if in_table and line.strip().startswith('|') and 'ID' in line:
                continue
            if in_table and line.strip().startswith('|') and '---' not in line:
                parts = [part.strip() for part in line.split('|') if part.strip()]
                if len(parts) >= 8 and 'риск' in parts[1].lower():
                    risks.append({
                        "risk_id": parts[0],
                        "type": "risk",
                        "name": parts[2],
                        "category": parts[3],
                        "risk_index": float(parts[4]) if self._is_float(parts[4]) else 0.0,
                        "priority": parts[5],
                        "escalation_potential": parts[6],
                        "urgency": parts[7],
                        "module_source": "10-4"
                    })
        
        return risks
    
    def _extract_opportunities(self, module_10_4_content: str) -> List[Dict]:
        """Извлекает возможности из модуля 10-4"""
        opportunities = []
        
        lines = module_10_4_content.split('\n')
        in_table = False
        
        for line in lines:
            if "СВОДНАЯ ТАБЛИЦА ПРИОРИТЕТОВ" in line:
                in_table = True
                continue
            if in_table and line.strip().startswith('|') and 'ID' in line:
                continue
            if in_table and line.strip().startswith('|') and '---' not in line:
                parts = [part.strip() for part in line.split('|') if part.strip()]
                if len(parts) >= 8 and 'возможность' in parts[1].lower():
                    opportunities.append({
                        "opportunity_id": parts[0],
                        "type": "opportunity",
                        "name": parts[2],
                        "category": parts[3],
                        "opportunity_index": float(parts[4]) if self._is_float(parts[4]) else 0.0,
                        "priority": parts[5],
                        "realization_potential": parts[6],
                        "timeframe": parts[7],
                        "module_source": "10-4"
                    })
        
        return opportunities
    
    def _extract_cross_module_connections(self, modules_data: Dict[str, str]) -> List[Dict]:
        """Извлекает межмодульные связи"""
        connections = []
        connection_patterns = ['СВЯЗЬ_10-', 'DYNAMIC_REF']
        
        for module_id, content in modules_data.items():
            lines = content.split('\n')
            for line in lines:
                for pattern in connection_patterns:
                    if pattern in line:
                        connections.append({
                            "source_module": module_id,
                            "connection_type": pattern.replace('_', '').replace('10-', ''),
                            "content": line.strip(),
                            "extracted_at": datetime.now().isoformat()
                        })
        
        return connections
    
    def _check_required_fields(self, entities: Dict, indices: Dict) -> bool:
        """Проверяет наличие обязательных полей"""
        required_entities = ['themes', 'emotions', 'personas']
        required_indices = ['content_health_index', 'audience_evolution_vector']
        
        for entity in required_entities:
            if not entities.get(entity):
                return False
        
        for index in required_indices:
            if index not in indices:
                return False
        
        return True
    
    def _calculate_completeness_score(self, entities: Dict, insights: List) -> float:
        """Рассчитывает оценку полноты данных"""
        total_entities = sum(len(entity_list) for entity_list in entities.values())
        insights_count = len(insights)
        
        # Максимально ожидаемое количество сущностей (эмпирически)
        max_expected_entities = 50
        max_expected_insights = 5
        
        entity_score = min(total_entities / max_expected_entities, 1.0)
        insight_score = min(insights_count / max_expected_insights, 1.0)
        
        return round((entity_score * 0.7 + insight_score * 0.3) * 100, 1)
    
    def _is_float(self, value: str) -> bool:
        """Проверяет, можно ли преобразовать строку в float"""
        try:
            float(value)
            return True
        except ValueError:
            return False